Colander
========

An extensible package which can be used to:

- deserialize and validate a data structure composed of strings,
  mappings, and lists.

- serialize an arbitrary data structure to a data structure composed
  of strings, mappings, and lists.

It runs on Python 2.6, 2.7 and 3.2.

Please see http://docs.pylonsproject.org/projects/colander/en/latest/
for further documentation.

See https://github.com/Pylons/colander for in-development version.
